launchpi
========

LaunchPI is an Eclipse plug-in that makes it possible to run and debug Java projects on your Raspberry PI directly from Eclipse

For news and installation instructions go here - http://tsvetan-stoyanov.github.io/launchpi/ 
